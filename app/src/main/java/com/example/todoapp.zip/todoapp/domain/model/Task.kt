package com.example.todoapp.domain.model

data class Task(
    val id: Long,
    val projectId: Long,
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val reminderDate: Long
)